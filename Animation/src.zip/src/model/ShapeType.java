package model;

/*
 * The emun includes rectangle, oval two type.
 */
public enum ShapeType {
  RECTANGLE, OVAL
}
