package model;

/*
 * The emun move, color, and scale three motion type.
 */
public enum AnimationType {
  MOVE, COLOR, SCALE
}
