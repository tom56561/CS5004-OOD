package cs5004.animator.view;

/**
 * The enum of view type.
 * 
 * @author eddie
 *
 */
public enum ViewType {
  ANIMATION, TEXT, SVG
}
