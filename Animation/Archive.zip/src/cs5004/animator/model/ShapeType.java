package cs5004.animator.model;

/**
 * The emun includes rectangle, oval two type.
 * 
 * @author eddie
 *
 */
public enum ShapeType {
  RECTANGLE, OVAL
}
