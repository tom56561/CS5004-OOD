package cs5004.animator.model;

/**
 * The emun move, color, and scale three motion type.
 * 
 * @author eddie
 *
 */
public enum AnimationType {
  MOVE, COLOR, SCALE
}
