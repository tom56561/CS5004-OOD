
public enum Collection {
  WINTER,
  SPRING,
  SUMMER,
  FALL
}
