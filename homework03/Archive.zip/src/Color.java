/**
 * Colors that can be used
 */

public enum Color {
  BLACK, WHITE
}
